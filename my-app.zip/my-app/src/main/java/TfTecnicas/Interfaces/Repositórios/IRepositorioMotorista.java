public interface IRepositorioMotorista{


    public Motorista recuperaPorCPF(String cpf);
    public void atualizaMotorista(Motorista motorista);
    
}


 