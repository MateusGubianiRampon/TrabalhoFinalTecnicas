public interface IRepositorioPassageiro{


    public Passageiro recuperaPorCPF(String cpf);
    public void atualizaPassageiro(Passageiro passageiro);
    
}


