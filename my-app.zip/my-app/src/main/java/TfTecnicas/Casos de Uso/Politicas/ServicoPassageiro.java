public class ServicoPassageiro{

    ServicoPassageiro(){
        
    }

    public void criarViagem(String cpf, Bairro origem, Bairro destino, FormaPagamento fPgto, String catVeiculo){

        
    }
    

}