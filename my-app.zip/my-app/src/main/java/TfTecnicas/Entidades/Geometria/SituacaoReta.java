public enum SituacaoReta{

    TODA_DENTRO, TODA_FORA, INTERSECTA
}