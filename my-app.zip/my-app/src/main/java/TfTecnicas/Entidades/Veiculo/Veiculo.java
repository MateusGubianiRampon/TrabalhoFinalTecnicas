package TfTecnicas.Entidades.Veiculo;

public abstract class Veiculo {

    public abstract String getPlaca();
    public abstract String getMarca();
    public abstract String getCor();
    public abstract String getCategoria();

    /*public String toString(){
        return "Placa : ", this.getPlaca(), "\n" ,
               "Marca :" , this.getMarca() , "\n" ,
               "Cor :"   , this.getCor();
    }*/


}