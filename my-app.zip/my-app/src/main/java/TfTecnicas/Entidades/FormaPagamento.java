package TfTecnicas.Entidades;

public enum FormaPagamento {

    DINHEIRO, DEBITO, CREDITO;

}